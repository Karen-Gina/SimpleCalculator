package com.example.dellc4.calcnew;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, bp, bmul, bmin, bdiv, beq, bcle, bdot;

    EditText t;
    //float mValueOne, mValueTwo;

   // boolean mAddition, mSubtract, mMultiplication, mDivision;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = (Button) findViewById(R.id.button);
        b2 = (Button) findViewById(R.id.button2);
        b3 = (Button) findViewById(R.id.button3);
        b4 = (Button) findViewById(R.id.button4);
        b5 = (Button) findViewById(R.id.button5);
        b6 = (Button) findViewById(R.id.button6);
        b7 = (Button) findViewById(R.id.button7);
        b8 = (Button) findViewById(R.id.button8);
        b9 = (Button) findViewById(R.id.button9);
        b0 = (Button) findViewById(R.id.button11);
        bp = (Button) findViewById(R.id.button10);
        bmul = (Button) findViewById(R.id.button13);
        bmin = (Button) findViewById(R.id.button15);
        bdiv = (Button) findViewById(R.id.button12);
        beq = (Button) findViewById(R.id.button14);
        bcle = (Button) findViewById(R.id.button16);
        bdot = (Button) findViewById(R.id.button17);
        t=(EditText)findViewById(R.id.editText);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setText(t.getText() + "1");
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setText(t.getText() + "2");
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setText(t.getText() + "3");
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setText(t.getText() + "4");
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setText(t.getText() + "5");
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setText(t.getText() + "6");
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setText(t.getText() + "7");
            }
        });

        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setText(t.getText() + "8");
            }
        });

        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setText(t.getText() + "9");
            }
        });

        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setText(t.getText() + "0");
            }
        });
        bcle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setText("");
            }
        });

        bdot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setText(t.getText() + ".");
            }
        });

        bp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*if (t == null) {
                    t.setText("");
                } else {
                    mValueOne = Float.parseFloat(t.getText() + "");
                    mAddition = true;
                    t.setText(null);
                }*/
                t.setText(t.getText() + "+");
            }
        });
        bmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*mValueOne = Float.parseFloat(t.getText() + "");
                mSubtract = true;
                t.setText(null);*/
                t.setText(t.getText() + "-");
            }
        });
        bmul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*mValueOne = Float.parseFloat(t.getText() + "");
                mMultiplication = true;
                t.setText(null);*/
                t.setText(t.getText() + "*");
            }
        });

        bdiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*mValueOne = Float.parseFloat(t.getText() + "");
                mDivision = true;
                t.setText(null);*/
                t.setText(t.getText() + "/");
            }
        });
        beq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float var=0;
                String res=t.getText().toString();
                if(res.contains("+")) {
                    String[] nums=res.split("\\+");
                    var=Float.parseFloat(nums[0])+Float.parseFloat(nums[1]);
                }
                else if(res.contains("-")) {
                    String[] nums=res.split("-");
                    var=Float.parseFloat(nums[0])-Float.parseFloat(nums[1]);
                }
                else if(res.contains("*")) {
                    String[] nums=res.split("\\*");
                    var=Float.parseFloat(nums[0])*Float.parseFloat(nums[1]);
                }
                else if(res.contains("/")) {
                    String[] nums=res.split("/");
                    var=Float.parseFloat(nums[0])/Float.parseFloat(nums[1]);
                }
                t.setText(var+"");
                /*
                mValueTwo = Float.parseFloat(t.getText() + "");

                if (mAddition == true) {

                    t.setText(mValueOne + mValueTwo + "");
                    mAddition = false;
                }


                if (mSubtract == true) {
                    t.setText(mValueOne - mValueTwo + "");
                    mSubtract = false;
                }

                if (mMultiplication == true) {
                    t.setText(mValueOne * mValueTwo + "");
                    mMultiplication = false;
                }

                if (mDivision == true) {
                    t.setText(mValueOne / mValueTwo + "");
                    mDivision = false;

                }*/
            }
        });


    }
}
